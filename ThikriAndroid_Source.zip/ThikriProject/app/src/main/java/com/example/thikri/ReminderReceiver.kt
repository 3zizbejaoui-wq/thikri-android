package com.example.thikri

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra("key") ?: return
        val data = when (key) {
            "morning" -> "أذكار الصباح" to "حان وقت أذكار الصباح 🌅"
            "evening" -> "أذكار المساء" to "حان وقت أذكار المساء 🌇"
            "sleep" -> "أذكار النوم" to "قبل أن تنام، لا تنس أذكار النوم 🌙"
            else -> "الاستيقاظ" to "صباح الخير، ابدأ يومك بذكر الله ☀️"
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel("daily_reminders", "تذكيرات ذِكري", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, "daily_reminders")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(data.first)
            .setContentText(data.second)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        manager.notify(key.hashCode(), notification)

        val prefs = context.getSharedPreferences("times", Context.MODE_PRIVATE)
        ReminderScheduler.schedule(
            context, key,
            prefs.getInt("${key}_hour", ReminderScheduler.defaultHour(key)),
            prefs.getInt("${key}_minute", ReminderScheduler.defaultMinute(key))
        )
    }
}
