package com.example.thikri

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object ReminderScheduler {
    private val reminders = listOf(
        Triple("morning", "أذكار الصباح", "حان وقت أذكار الصباح 🌅"),
        Triple("evening", "أذكار المساء", "حان وقت أذكار المساء 🌇"),
        Triple("sleep", "أذكار النوم", "قبل أن تنام، لا تنس أذكار النوم 🌙"),
        Triple("wake", "الاستيقاظ", "صباح الخير، ابدأ يومك بذكر الله ☀️")
    )

    fun scheduleAll(context: Context) {
        reminders.forEach { (key, _, _) ->
            val prefs = context.getSharedPreferences("times", Context.MODE_PRIVATE)
            val hour = prefs.getInt("${key}_hour", defaultHour(key))
            val minute = prefs.getInt("${key}_minute", defaultMinute(key))
            schedule(context, key, hour, minute)
        }
    }

    fun schedule(context: Context, key: String, hour: Int, minute: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("key", key)
        val pi = PendingIntent.getBroadcast(
            context, key.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !alarmManager.canScheduleExactAlarms()) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        } else {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        }
    }

    fun defaultHour(key: String) = when (key) {
        "morning" -> 7
        "evening" -> 17
        "sleep" -> 22
        else -> 6
    }
    fun defaultMinute(key: String) = when (key) {
        "sleep" -> 30
        else -> 0
    }
}
