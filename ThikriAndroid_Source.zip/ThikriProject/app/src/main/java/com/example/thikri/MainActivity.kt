package com.example.thikri

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private val green = Color.rgb(16, 44, 39)
    private val gold = Color.rgb(181, 138, 69)
    private val cream = Color.rgb(248, 246, 239)

    private val morning = listOf(
        "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ..." to 1,
        "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا..." to 1,
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ" to 100,
        "قُلْ هُوَ اللَّهُ أَحَدٌ، وَالْمُعَوِّذَتَانِ" to 3
    )
    private val evening = listOf(
        "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ..." to 1,
        "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا..." to 1,
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ" to 100,
        "قُلْ هُوَ اللَّهُ أَحَدٌ، وَالْمُعَوِّذَتَانِ" to 3
    )
    private val sleep = listOf(
        "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا" to 1,
        "اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ" to 3,
        "آية الكرسي" to 1,
        "جمع الكفين وقراءة الإخلاص والفلق والناس والنفث فيهما ومسح الجسد" to 3
    )
    private val wake = listOf(
        "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ" to 1
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        ReminderScheduler.scheduleAll(this)
        showHome()
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(cream)
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(24, 28, 24, 24)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(8, 12, 8, 12)
        }

    private fun button(value: String, action: () -> Unit): Button =
        Button(this).apply {
            text = value
            setTextColor(Color.WHITE)
            setBackgroundColor(green)
            setOnClickListener { action() }
        }

    private fun showHome() {
        val root = baseLayout()
        root.addView(text("ذِكري", 32f, green, true))
        root.addView(text("وَاذْكُرْ رَبَّكَ كَثِيرًا", 17f, gold))
        root.addView(text("رفيقك اليومي للذكر والطمأنينة", 16f, green))
        root.addView(button("أذكار الصباح",) { showAzkar("أذكار الصباح", morning) })
        root.addView(button("أذكار المساء") { showAzkar("أذكار المساء", evening) })
        root.addView(button("أذكار النوم") { showAzkar("أذكار النوم", sleep) })
        root.addView(button("أذكار الاستيقاظ") { showAzkar("أذكار الاستيقاظ", wake) })
        root.addView(button("مواعيد التنبيهات والمنبّه") { showSettings() })
        root.addView(text("التنبيهات تعمل يوميًا ويمكن تعديل أوقاتها من الإعدادات.", 13f, Color.DKGRAY))
        setContentView(root)
    }

    private fun showAzkar(title: String, items: List<Pair<String, Int>>) {
        val root = baseLayout()
        root.addView(text(title, 26f, green, true))
        items.forEachIndexed { index, item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.WHITE)
                setPadding(12, 8, 12, 8)
            }
            card.addView(text(item.first, 19f, green, true))
            val count = TextView(this).apply {
                text = "التكرار: ${item.second}"
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(gold)
            }
            val current = intArrayOf(0)
            val counter = button("اضغط للتسبيح  •  0 / ${item.second}") {
                current[0]++
                if (current[0] >= item.second) {
                    count.text = "اكتمل الذكر ✓"
                } else count.text = "التكرار: ${item.second - current[0]} متبقٍ"
            }
            card.addView(count)
            card.addView(counter)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 18
            root.addView(card, lp)
        }
        root.addView(button("العودة للرئيسية") { showHome() })
        setContentView(root)
    }

    private fun showSettings() {
        val root = baseLayout()
        root.addView(text("مواعيد التنبيهات", 26f, green, true))
        val prefs = getSharedPreferences("times", MODE_PRIVATE)
        val labels = listOf(
            "morning" to "أذكار الصباح",
            "evening" to "أذكار المساء",
            "sleep" to "تذكير النوم",
            "wake" to "منبّه الاستيقاظ"
        )
        labels.forEach { (key, label) ->
            val hour = prefs.getInt("${key}_hour", ReminderScheduler.defaultHour(key))
            val minute = prefs.getInt("${key}_minute", ReminderScheduler.defaultMinute(key))
            root.addView(button("$label  —  %02d:%02d".format(hour, minute)) {
                TimePickerDialog(this, { _, h, m ->
                    prefs.edit().putInt("${key}_hour", h).putInt("${key}_minute", m).apply()
                    ReminderScheduler.schedule(this, key, h, m)
                    showSettings()
                }, hour, minute, true).show()
            })
        }
        root.addView(button("العودة للرئيسية") { showHome() })
        setContentView(root)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }
}
